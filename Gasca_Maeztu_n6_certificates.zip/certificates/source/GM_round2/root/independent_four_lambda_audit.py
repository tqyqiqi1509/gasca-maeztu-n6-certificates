from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
import sympy as s,json,time
D=Path('GM_round2/root'); src=Path('GM_round2/maximal_quartic_fresh')
r,u,v=s.symbols('r u v'); U=[s.Integer(1),-1/r,u,v]
# Independently construct all partial injective maps of size two.
edges=[(i,j) for i in (1,2,3) for j in (0,2,3) if i!=j]
pairs=sorted({tuple(sorted(((i,j),(k,l)))) for i,j in edges for k,l in edges if i!=k and j!=l})
assert len(pairs)==11
bad=[r,r+1,u,v,u-1,v-1,r*u+1,r*v+1,u-v,1+(r-1)*u,1+(r-1)*v,r*u-r+1,r*v-r+1]
def canonical(p):return s.Poly(p,r,u,v).monic().as_expr()
B={canonical(p) for p in bad}; results=[]; t0=time.time()
for P,Q in ((P,Q) for P in pairs for Q in pairs):
 eq=[]; raw=[]; immediate=False
 for typ,es in [(0,P),(1,Q)]:
  for i,j in es:
   # Use direct rational map equality, independently clearing denominators.
   z=(U[i]-1)/r-U[j] if typ==0 else U[i]/(r*(1-U[i]))-U[j]
   num=s.together(z).as_numer_denom()[0];raw.append(str(s.factor(num)))
   if num==0:continue
   fs=[p**e for p,e in s.factor_list(num)[1] if canonical(p) not in B]
   if not fs:immediate=True;break
   eq.append(s.prod(fs))
  if immediate:break
 if immediate:results.append({'P':P,'Q':Q,'status':'immediate'});continue
 # Reverse the author's elimination-variable priority.
 gb=s.groebner(eq,v,u,r,order='lex',domain=s.QQ)
 forced=[str(p) for p in bad if gb.reduce(p)[1]==0]
 if forced:status='forbidden'
 else:
  uni=[p for p in gb if p.free_symbols<=set([r])]
  assert uni,(P,Q,list(gb))
  h=s.factor(uni[0]); candidates=[]
  for f,e in s.factor_list(h)[1]:
   if s.degree(f,r)==0:continue
   if canonical(f) in B:continue
   if s.Poly(f,r).count_roots(-s.oo,s.oo)>0:candidates.append(f)
  status='nonreal_or_forbidden' if not candidates else 'cubic'
  if candidates:assert len(candidates)==1 and s.degree(candidates[0],r)==3,(P,Q,candidates)
 results.append({'P':P,'Q':Q,'status':status,'gb':list(map(str,gb)),'forced':forced})
counts=dict(Counter(x['status'] for x in results));print(counts,flush=True)
# Compare statuses by incidence tuples, not by the author's integer indices.
auth=json.loads((src/'four_carrier_lambda_graphs.json').read_text())
assert {tuple(tuple(e) for e in p) for p in pairs}=={tuple(tuple(e) for e in p) for p in auth['pairs']}
# Independently rebuild each surviving field completion via homogeneous cross products.
completion=[]
for row in results:
 if row['status']!='cubic':continue
 gb=[s.sympify(x) for x in row['gb']]; f=next(p for p in gb if p.free_symbols<={r})
 def norm(z):
  n,d=s.together(z).as_numer_denom();return s.rem(s.rem(n,f,r)*s.invert(s.rem(d,f,r),f,r),f,r).expand()
 uv=s.solve(gb[:-1],[u,v],dict=True)
 if not uv:
  uv=s.solve([p for p in gb if p.free_symbols-{r}],[u,v],dict=True)
 assert len(uv)==1,(gb,uv)
 vals=list(map(norm,[1,-1/r,uv[0][u],uv[0][v]]))
 def uniq(seq):return list(dict.fromkeys(norm(z) for z in seq))
 roots=[uniq([0,1]+[-r*w for w in vals]+[1-w for w in vals]),uniq([0,1]+vals+[1+r*w for w in vals]),uniq([0,1]+[-1/(r*w) for w in vals]+[1-1/w for w in vals]),uniq([0,1]+[1/w for w in vals]+[1+1/(r*w) for w in vals])]
 assert [len(z) for z in roots]==[6]*4
 checks=[]
 for lam in vals[2:]:
  corners=[(norm(0),norm(lam)),(norm(1),norm(1+r*lam)),(norm(-r*lam),norm(0)),(norm(1-lam),norm(1))]
  lefta=[x for x in roots[0] if x not in [q[0] for q in corners]];leftb=[x for x in roots[1] if x not in [q[1] for q in corners]]
  assert len(lefta)==len(leftb)==2
  for perm in permutations(leftb):
   pairs2=corners+list(zip(lefta,perm)); hits=[[],[]]; valid=True
   for aa,bb in pairs2:
    line=s.Matrix([0,aa,1]).cross(s.Matrix([1,bb,1]))
    for k,carrier in enumerate([s.Matrix([0,1,0]),s.Matrix([0,1,-1])]):
     pt=line.cross(carrier)
     if norm(pt[2])==0:valid=False;break
     hits[k].append(norm(pt[0]/pt[2]))
    if not valid:break
   good=valid and all(len(set(hits[k]))==6 and set(hits[k])==set(roots[k+2]) for k in (0,1))
   assert not good,(f,vals,lam,pairs2)
   checks.append({'lambda':str(lam),'matches_all_four':bool(good),'distinct_EF':[len(set(z)) for z in hits]})
  
 completion.append({'P':row['P'],'Q':row['Q'],'field':str(f),'parameters':list(map(str,vals)),'checks':checks})
assert len(completion)==8
out={'counts':counts,'injection_count':11,'cases':results,'completion':completion,'seconds':time.time()-t0,'status':'PASS'}
(D/'independent_four_lambda_audit.json').write_text(json.dumps(out,indent=2))
print('PASS completions',len(completion),'seconds',time.time()-t0)
