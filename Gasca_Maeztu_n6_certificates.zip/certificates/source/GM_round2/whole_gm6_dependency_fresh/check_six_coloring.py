"""Independent verification of the complete concurrent-five matching bound.

The supplied colors are treated only as a proposed certificate. All matching
vertices and every compatibility edge are regenerated independently here.
"""
import itertools
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
source = BASE.parent / 'inverse_core_fresh/ordered_matching_six_coloring.json'
certificate = json.loads(source.read_text())
vertices = []
for p in itertools.permutations(range(5)):
    for q in itertools.permutations(range(5)):
        triples = tuple((i, p[i], q[i]) for i in range(5))
        if all(not (p[i] < p[j] and q[i] < q[j])
               for i in range(5) for j in range(i+1, 5)):
            vertices.append(triples)
supplied = [tuple(map(tuple, v)) for v in certificate['matchings']]
assert set(vertices) == set(supplied)
assert len(vertices) == len(supplied) == len(set(supplied)) == 1899
color = dict(zip(supplied, certificate['colors']))
assert set(color.values()) == set(range(6))

# Weak coordinate comparisons matter between distinct matchings: two triples
# sharing one coordinate can still be comparable in the product order.
all_triples = list(itertools.product(range(5), repeat=3))
index = {v: i for i, v in enumerate(all_triples)}
badmask = []
for v in all_triples:
    mask = 0
    for w in all_triples:
        if v != w and (all(a <= b for a, b in zip(v, w)) or
                       all(b <= a for a, b in zip(v, w))):
            mask |= 1 << index[w]
    badmask.append(mask)
masks = [sum(1 << index[t] for t in v) for v in vertices]
forbidden = [0] * len(vertices)
for i, v in enumerate(vertices):
    for t in v:
        forbidden[i] |= badmask[index[t]]

edge_count = 0
for i, v in enumerate(vertices):
    for j in range(i):
        if not (forbidden[i] & masks[j]):
            edge_count += 1
            assert color[v] != color[vertices[j]], (i, j)
assert edge_count == 2991
result = {
    'status': 'PASS',
    'regenerated_vertices': len(vertices),
    'regenerated_edges': edge_count,
    'certificate_colors': len(set(color.values())),
    'scope': 'Every simultaneous real concurrent-five-core matching family has at most six partitions.'
}
(BASE / 'six_coloring_audit.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
