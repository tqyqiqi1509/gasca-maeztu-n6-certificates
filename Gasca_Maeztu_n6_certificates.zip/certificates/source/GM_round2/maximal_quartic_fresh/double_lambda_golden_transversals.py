"""Exact golden-ratio boundary: three split sextics, unique special quartic."""
import sympy as s,itertools,json
from pathlib import Path
D=Path('GM_round2/maximal_quartic_fresh');z,x,y=s.symbols('z x y');f=z*z-3*z+1

def norm(q):
 n,d=s.together(q).as_numer_denom();return s.rem(n*s.invert(d,f,z),f,z).expand()
def normpoly(p):return s.Poly(p,x,y).from_dict({ij:norm(c)for ij,c in s.Poly(p,x,y).terms()},(x,y)).as_expr()
S=[z,1-z,3-z,z-2];edges=[]
for i,j in itertools.permutations(range(4),2):
 a,b=S[i],S[j];e=norm(a/(a-b));ff=norm((a-1)/(a-b))
 edges.append({'pair':[i,j],'E':str(e),'F':str(ff),'eligible':e in S and ff in S})
perms=[]
for p in itertools.permutations(range(4)):
 if all(any(e['pair']==[i,p[i]]and e['eligible']for e in edges)for i in range(4)):perms.append(p)
line=lambda a,b:y-a-(b-a)*x
R=s.prod(line(S[i],S[perms[0][i]])for i in range(4))
P0=normpoly((y-x)*(y+x-1)*R)
Ps=[P0];allpairs=[]
for lam,other in[(z,3-z),(3-z,z)]:
 pairs=[(0,lam),(1,1-lam),(lam,0),(1-lam,1),(other,1-other),(1-other,other)]
 Ps.append(normpoly(s.prod(line(a,b)for a,b in pairs)));allpairs.append(pairs)
roots=[0,1]+S;rootpoly=s.expand(s.prod(y-a for a in roots));checks=[]
for P in Ps:
 A=normpoly(P.subs(x,0)-rootpoly);B=normpoly(P.subs(x,1)-rootpoly)
 mu=norm(s.Poly(P.subs(y,0),x).LC());E=normpoly(P.subs(y,0)-mu*rootpoly.subs(y,x));F=normpoly(P.subs(y,1)-mu*rootpoly.subs(y,x))
 checks.append({'multiplier':str(mu),'restriction_remainders':list(map(str,[A,B,E,F]))})
monoms=[x**i*y**j for i in range(7)for j in range(7-i)];minor=None
for inds in itertools.combinations(range(len(monoms)),3):
 M=s.Matrix([[s.Poly(P,x,y).coeff_monomial(monoms[k])for k in inds]for P in Ps]);det=norm(M.det())
 if det!=0:minor={'monomials':[str(monoms[k])for k in inds],'determinant':str(det)};break
out={'minimal_polynomial':str(f),'S':list(map(str,S)),'edges':edges,'quartic_permutations':perms,'sextics':list(map(str,Ps)),'restriction_checks':checks,'independence_minor':minor}
(D/'double_lambda_golden_transversals.json').write_text(json.dumps(out,indent=2))
print('eligible',[e['pair']for e in edges if e['eligible']]);print('quartics',perms);print('checks',checks);print('rank3minor',minor)
