import itertools,json,pathlib,collections
n=5
perms=list(itertools.permutations(range(n)))
ident=tuple(range(n))
latin=[]
def build(rows):
    if len(rows)==n:
        latin.append(tuple(rows));return
    for p in perms:
        if all(all(p[j]!=r[j] for r in rows) for j in range(n)):
            build(rows+[p])
build([ident])
reduced=[L for L in latin if tuple(row[0] for row in L)==ident]
stats=collections.Counter();examples={}; affine_certificates=[]; nonaffine=[]
for P in reduced:
    for Q in latin:
        for missing in range(1,n):
            used={(P[i][j],Q[i][j]) for i in range(n) if i!=missing for j in range(n)}
            if len(used)!=20:continue
            new=[j for j in range(n) if (P[missing][j],Q[missing][j]) not in used]
            stats[len(new)]+=1
            examples.setdefault(len(new),{'P':P,'Q':Q,'missing':missing,'new_columns':new})
            cert=None
            for tail in itertools.permutations(range(1,n)):
                c=(0,)+tail
                if not all(c[P[s][i]]==(c[s]+c[i])%n for s in range(n) for i in range(n)): continue
                for a in (2,3,4):
                    if all(c[Q[s][i]]==(a*c[s]+c[i])%n for s in range(n) for i in range(n)):
                        cert={'P':P,'Q':Q,'missing':missing,'coordinate_labels':c,'slope':a};break
                if cert:break
            if cert: affine_certificates.append(cert)
            else: nonaffine.append({'P':P,'Q':Q,'missing':missing})
out={'first_row_normalized_squares':len(latin),'reduced_squares':len(reduced),'pairs_and_missing_rows_checked':len(latin)*len(reduced)*4,'completion_new_triples_histogram':dict(stats),'examples':examples,'affine_certificate_count':len(affine_certificates),'nonaffine_survivors':nonaffine,'affine_certificates':affine_certificates,'scope':'All normalized pairwise Latin matchings for three 5-line families with four shared transverse carriers; no real realizability or metric coordinate assumption.'}
p=pathlib.Path(__file__).with_suffix('.json');p.write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='affine_certificates'},indent=2))
