"""Complete finite incidence classification and symbolic real obstruction.

This enumerates permutations of five labels, never numerical point coordinates.
Run with Python 3 + Sympy.  Output is shared_four_carrier_certificate.json.
"""
import collections
import itertools
import json
import pathlib
import sympy as S

OUT = pathlib.Path(__file__).with_suffix('.json')
ID = tuple(range(5))
PERMS5 = list(itertools.permutations(range(5)))


def latin_squares(n):
    perms = list(itertools.permutations(range(n)))
    result = []

    def visit(rows):
        if len(rows) == n:
            result.append(tuple(rows))
            return
        for row in perms:
            if all(all(row[j] != old[j] for j in range(n)) for old in rows):
                visit(rows + [row])

    visit([tuple(range(n))])
    return result


def inverse(p):
    return tuple(p.index(i) for i in range(5))


def relabel(P, Q, rows, alpha):
    ip, iq, ia = inverse(P[rows[0]]), inverse(Q[rows[0]]), inverse(alpha)
    return (
        tuple(tuple(alpha[ip[P[r][ia[j]]]] for j in range(5)) for r in rows),
        tuple(tuple(alpha[iq[Q[r][ia[j]]]] for j in range(5)) for r in rows),
    )


def canonical(P, Q):
    return min(relabel(P, Q, rr, aa)
               for rr in itertools.permutations(range(4)) for aa in PERMS5)


L4, L5 = latin_squares(4), latin_squares(5)
R4 = [L for L in L4 if tuple(row[0] for row in L) == tuple(range(4))]
one, two = [], []
for smallP in R4:
    P = tuple((0,) + tuple(j + 1 for j in row) for row in smallP)
    for fullQ in L5:
        Q = fullQ[:4]
        if len({(P[r][i], Q[r][i]) for r in range(4) for i in range(5)}) == 20:
            one.append((P, Q))
    remaining = (0, 2, 3, 4)
    for smallQ in L4:
        Q = []
        for row in smallQ:
            q = list(ID)
            for j, i in enumerate(remaining):
                q[i] = remaining[row[j]]
            Q.append(tuple(q))
        Q = tuple(Q)
        if len({(P[r][i], Q[r][i]) for r in range(4) for i in range(5)}) == 20:
            two.append((P, Q))

one_classes = collections.Counter(canonical(*z) for z in one)
two_classes = collections.Counter(canonical(*z) for z in two)
assert (len(L4), len(L5), len(R4), len(one), len(two)) == (24, 1344, 4, 40, 8)
assert sorted(one_classes.values()) == [8, 32]
assert sorted(two_classes.values()) == [2, 6]

P0 = (ID, (0, 2, 1, 4, 3), (0, 3, 4, 1, 2), (0, 4, 3, 2, 1))
BAD = (P0, (ID, (1, 3, 4, 0, 2), (3, 4, 1, 2, 0), (4, 2, 0, 1, 3)))
T1 = (P0, (ID, (1, 3, 4, 2, 0), (4, 2, 3, 0, 1), (3, 0, 1, 4, 2)))
T2 = (P0, (ID, (1, 0, 3, 2, 4), (3, 2, 1, 0, 4), (2, 3, 0, 1, 4)))
T3 = ((ID, (0, 2, 1, 4, 3), (0, 3, 4, 2, 1), (0, 4, 3, 1, 2)),
      (ID, (1, 0, 3, 2, 4), (3, 2, 0, 1, 4), (2, 3, 1, 0, 4)))
assert one_classes[BAD] == 32 and one_classes[T1] == 8
assert two_classes[T2] == 2 and two_classes[T3] == 6

u, v = S.symbols('u v', nonzero=True)
oneS, zeroS = S.S.One, S.S.Zero
noncollinear = [
    ([u*v, u, u*u/v, u/v, oneS], [v*v/u, u*v, u, v, oneS]),
    ([u*u, u, u*u/v, u/v, oneS], [v*v, u*v, u, v, oneS]),
    ([u**3, u*u, v, u, oneS], [u, v, v/u, v/(u*u), oneS]),
]
collinear = [
    ([u+v, u, 2*u-v, u-v, zeroS], [-u+2*v, u+v, u, v, zeroS]),
    ([2*u, u, 2*u-v, u-v, zeroS], [2*v, u+v, u, v, zeroS]),
    ([3*u-3*v, 2*u-2*v, 2*u-v, u-v, zeroS], [u-v, 2*u-v, u, v, zeroS]),
]


def equations(P, Q, x, y, multiplicative):
    result = []
    for rows in (P, Q):
        inv1 = inverse(rows[1])
        for i in range(5):
            j, k = rows[2][i], inv1[rows[2][i]]
            if multiplicative:
                result.append(x[i]*y[j] - x[k]*y[i])
            else:
                result.append(x[i] + y[j] - x[k] - y[i])
    return result


def fourth_matrix(P, Q, x, y, multiplicative):
    result = []
    for rows in (P, Q):
        inv1 = inverse(rows[1])
        for i in range(5):
            j, k = rows[3][i], inv1[rows[3][i]]
            row = [y[j]-y[i], x[i]-x[k]]
            if multiplicative:
                row.append(x[k]*y[i]-x[i]*y[j])
            result.append(row)
    return S.Matrix(result)


H = u*u-u*v-u+v*v-v+1
A = u*u*v-2*u*u+u*v+u-v*v
C = u*u*v-u*v-u-v*v+2*v
D = u**3*v+u*u-u*v-v
E = u**3-u*v+u-v
assert S.expand(2*H-((u-v)**2+(u-1)**2+(v-1)**2)) == 0
assert S.expand(A-C+2*(u-v)*(u-1)) == 0
assert S.expand((u+1)*D+(u**3-u-1)*E-u*(u**5-1)) == 0
indices = [[(1, 2, 6)], [(1, 2, 6), (1, 2, 7)], [(1, 2, 5), (1, 2, 7)]]
expected = [[u*(u-1)**2*H], [-u*u*(u-1)**2*C/v, u*(u-1)**2*A],
            [(u-1)*(u-v)**2*D/(u*u), -v*(u-1)*(u-v)**2*E/(u*u)]]
linear_indices = [(4, 9), (4, 5), (1, 6)]
linear_expected = [u*u-u*v+v*v, 3*(u*u-u*v+v*v), 2*u*u-2*u*v+v*v]

records = []
for n, (P, Q) in enumerate((T1, T2, T3)):
    automorphisms = []
    for rr in itertools.permutations(range(4)):
        for aa in PERMS5:
            if relabel(P, Q, rr, aa) == (P, Q):
                automorphisms.append((rr, aa))
    assert {rr[3] for rr, aa in automorphisms} == set(range(4))
    witnesses = {str(j): next((rr, aa) for rr, aa in automorphisms if rr[3] == j)
                 for j in range(4)}
    x, y = noncollinear[n]
    assert all(S.cancel(f) == 0 for f in equations(P, Q, x, y, True))
    # Completeness: the eight-variable equations imply the stated parametrization,
    # after multiplication by nonzero monomials.  Verify by polynomial reduction.
    xx = S.symbols('x0:4') + (oneS,)
    yy = S.symbols('y0:4') + (oneS,)
    g = S.groebner(equations(P, Q, xx, yy, True), *(xx[:4]+yy[:4]))
    substitution = {u: yy[2], v: yy[3]} if n < 2 else {u: yy[0], v: yy[1]}
    for actual, expression in zip(xx+yy, x+y):
        diff = S.together(actual-expression.subs(substitution))
        numerator, denominator = S.fraction(diff)
        # Multiplying by the product of all nonzero coordinates performs only
        # a logically permitted cancellation; four powers suffice here.
        multiplier = S.prod(xx[:4]+yy[:4])
        assert any(g.reduce(S.expand(numerator*multiplier**power))[1] == 0
                   for power in range(5))
    N = fourth_matrix(P, Q, x, y, True)
    dets = [S.factor(N[list(inds), :].det()) for inds in indices[n]]
    assert all(S.cancel(d-e) == 0 for d, e in zip(dets, expected[n]))
    lx, ly = collinear[n]
    assert all(S.expand(f) == 0 for f in equations(P, Q, lx, ly, False))
    lxx = S.symbols('x0:4')+(zeroS,)
    lyy = S.symbols('y0:4')+(zeroS,)
    general_linear = list(S.linsolve(equations(P, Q, lxx, lyy, False),
                                    lxx[:4]+lyy[:4]))[0]
    assert all(S.expand(a-b.subs({u:lyy[2],v:lyy[3]})) == 0
               for a,b in zip(general_linear, lx[:4]+ly[:4]))
    LN = fourth_matrix(P, Q, lx, ly, False)
    ldet = S.factor(LN[list(linear_indices[n]), :].det())
    assert S.expand(ldet-linear_expected[n]) == 0
    records.append({
        'type': n+1, 'P': P, 'Q': Q, 'automorphisms': len(automorphisms),
        'row_transitivity_witnesses': witnesses,
        'noncollinear_x': list(map(str, x)), 'noncollinear_y': list(map(str, y)),
        'three_center_groebner': [str(z.as_expr()) for z in g.polys],
        'fourth_center_minor_indices_zero_based': indices[n],
        'fourth_center_minors': list(map(str, dets)),
        'collinear_x': list(map(str, lx)), 'collinear_y': list(map(str, ly)),
        'collinear_minor_indices_zero_based': linear_indices[n],
        'collinear_minor': str(ldet),
    })

result = {
    'status': 'all assertions passed',
    'enumeration_counts': {'latin4_firstrow_identity':len(L4),
                           'latin4_reduced':len(R4), 'latin5_firstrow_identity':len(L5),
                           'one_shared':len(one), 'two_shared':len(two)},
    'one_shared_orbits': [{'P':P,'Q':Q,'count':count} for (P,Q),count in one_classes.items()],
    'two_shared_orbits': [{'P':P,'Q':Q,'count':count} for (P,Q),count in two_classes.items()],
    'records': records,
    'one_shared_all_patterns': one,
    'two_shared_all_patterns': two,
}
OUT.write_text(json.dumps(result, indent=2))
print(json.dumps({k:result[k] for k in ('status','enumeration_counts')}, indent=2))
print('One-shared orbit sizes:', sorted(one_classes.values()))
print('Two-shared orbit sizes:', sorted(two_classes.values()))
print('All exact parameter-completeness, determinant, identity, and row-transitivity checks passed.')
