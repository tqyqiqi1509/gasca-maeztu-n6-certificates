"""Fresh direct verifier, from the mathematical definition of linearity."""
from itertools import permutations, combinations
from pathlib import Path
import json

perms=list(permutations(range(5)))
candidates=[]
for p in perms:
    if p[0] != 1: continue
    for q in perms:
        if q[0] != 2: continue
        if any(len({i,p[i],q[i]}) != 3 for i in range(5)): continue
        candidates.append(frozenset((i,p[i],q[i]) for i in range(5)))

def linear(edges):
    return all(sum(x==y for x,y in zip(a,b))<=1 for a,b in combinations(edges,2))

adj=[set() for _ in candidates]
for i,j in combinations(range(len(candidates)),2):
    if linear(candidates[i]|candidates[j]):adj[i].add(j);adj[j].add(i)
triangles=[(i,j,k) for i,j,k in combinations(range(len(candidates)),3)
           if j in adj[i] and k in adj[i] and k in adj[j]]
out={'candidates':len(candidates),'edges':sum(map(len,adj))//2,'triangles':len(triangles),
     'definition':'all pairs of distinct hyperedges share at most one vertex',
     'status':'PASS' if len(candidates)==46 and sum(map(len,adj))==116 and not triangles else 'FAIL'}
assert out['status']=='PASS'
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(out)
