"""Independent simultaneous-row search for zero shared factors."""
from itertools import permutations,combinations
from pathlib import Path
import json,time
start=time.time();P5=list(permutations(range(5)));ID=tuple(range(5))
nexts={p:[q for q in P5 if all(a!=b for a,b in zip(p,q))] for p in P5}
results=[]
def rec(P,Q):
    if len(P)==4:
        rp=tuple(next(k for k in range(5)if all(k!=p[i]for p in P))for i in range(5))
        rq=tuple(next(k for k in range(5)if all(k!=q[i]for q in Q))for i in range(5))
        assert len(set(rp))==len(set(rq))==5
        results.append((tuple(P+[rp]),tuple(Q+[rq])));return
    op={(p[i],q[i])for p,q in zip(P,Q)for i in range(5)}
    for p in nexts[P[-1]]:
        if any(p[i]==old[i]for old in P[:-1]for i in range(5)):continue
        for q in nexts[Q[-1]]:
            if any(q[i]==old[i]for old in Q[:-1]for i in range(5)):continue
            if any((p[i],q[i])in op for i in range(5)):continue
            rec(P+[p],Q+[q])
rec([ID],[ID])
norm={}
for P,Q in results:
    order=sorted(range(5),key=lambda r:P[r][0]);missing=order.index(4)
    np=tuple(P[r]for r in order);nq=tuple(Q[r]for r in order)
    assert len({(np[r][i],nq[r][i])for r in range(5)for i in range(5)})==25
    key=(np,nq,missing)
    witnesses=[]
    for tail in permutations(range(1,5)):
        c=(0,)+tail
        if all(c[np[r][i]]==(c[r]+c[i])%5 for r in range(5)for i in range(5)):
            for a in (2,3,4):
                if all(c[nq[r][i]]==(a*c[r]+c[i])%5 for r in range(5)for i in range(5)):witnesses.append((c,a))
    assert witnesses;norm[key]=witnesses
cert=json.loads(Path('GM_round2/support4_fresh/partial_net_latin.json').read_text())
expected={(tuple(map(tuple,r['P'])),tuple(map(tuple,r['Q'])),r['missing']) for r in cert['affine_certificates']}
assert set(norm)==expected
assert all(any(set(((b+d*k)%5 for k in range(3)))==set(tri)for b in range(5)for d in range(1,5))for tri in combinations(range(5),3))
out={'firstrow_fixed_fourrow_patterns':len(results),'normalized_with_distinguished_missing_row':len(norm),'exactly_equal_supplied_certificate':True,'all_completions_orthogonal':True,'all_have_cyclic_affine_witness':True,'every_three_carrier_labels_arithmetic_progression':True,'seconds':time.time()-start}
Path('GM_round2/early_gm6_exclusions_fresh/zero_shared_replay.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
