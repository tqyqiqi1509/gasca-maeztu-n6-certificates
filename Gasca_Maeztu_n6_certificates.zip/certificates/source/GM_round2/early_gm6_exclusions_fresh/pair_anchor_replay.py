"""Independent pair-anchored verifier of the rich-affine-conic calculation.
All possible maps determined by TWO source/target matches are enumerated;
activation is checked by direct image membership, not stored triple witnesses.
Uses exact rational/algebraic fields and a separate determinant implementation.
"""
from itertools import combinations,permutations
from collections import defaultdict
from pathlib import Path
import sympy as S,json,time,argparse
from sympy.polys.polyclasses import ANP
t=S.symbols('t')

def determinant(rows):
    m=[list(r)for r in rows];n=len(m);v=1
    for col in range(n):
        k=next((k for k in range(col,n)if m[k][col]),None)
        if k is None:return 0
        if k!=col:m[k],m[col]=m[col],m[k];v=-v
        pivot=m[col][col];v*=pivot
        inv=(pivot/pivot)/pivot
        m[col]=[x*inv for x in m[col]]
        for i in range(col+1,n):
            f=m[i][col]
            m[i]=[x-f*y for x,y in zip(m[i],m[col])]
    return v
def conic_bad(maps):
    tests=0
    for pp in combinations(maps,6):
        if any(not determinant([[r,s,1]for r,s in tri])for tri in combinations(pp,3)):continue
        tests+=1
        if not determinant([[r*r,r*s,s*s,r,s,1]for r,s in pp]):return True,tests
    return False,tests

def run(label,A,base,domain,all_roots=False):
    R=base.frac_field(t)
    def canonical(z):return R.to_sympy(R.from_sympy(z))
    A=list(map(canonical,A));out=[];started=time.time()
    def nd(z):
        n,d=S.fraction(canonical(z));return S.Poly(n,t,domain=base),S.Poly(d,t,domain=base)
    def key(p):return tuple(p.monic().all_coeffs())
    for omit in range(5):
        C=A[:omit]+A[omit+1:];maps=set();events={};factorcache={}
        def add_event(z):
            p=nd(z)[0]
            if p.is_zero or p.degree()==0:return
            kk=key(p)
            if kk not in factorcache:
                fs=[]
                for f,e in S.factor_list(p)[1]:
                    if f.degree()==0:continue
                    if all_roots or f.count_roots(*domain)>0:fs.append(f.monic())
                factorcache[kk]=fs
            for f in factorcache[kk]:events[key(f)]=f
        for aa,bb in combinations(range(5),2):
            for cc,dd in permutations(range(4),2):
                r=canonical((C[dd]-C[cc])/(A[bb]-A[aa]));s=canonical(C[cc]-r*A[aa]);maps.add((r,s))
        generic=[]
        for r,s in maps:
            ims=[canonical(r*a+s)for a in A]
            if sum(x in C for x in ims)>=3:generic.append((r,s,ims))
            for x in ims:
                for c in C:
                    if x!=c:add_event(x-c)
        baseline=set();extra=defaultdict(set)
        for r,s,ims in generic:
            off=[x for x in ims if x not in C]
            if len(off)==1:baseline.add((r,s))
            else:
                assert len(off)==2
                for b in off:extra[b].add((r,s))
        assert len(baseline)<=4
        for b,c in combinations(extra,2):add_event(b-c)
        generic_tests=0
        for b,mm in extra.items():
            P=baseline|mm
            if len(P)<6:continue
            for six in combinations(P,6):
                if any(canonical(S.Matrix([[r,s,1]for r,s in tri]).det())==0 for tri in combinations(six,3)):continue
                generic_tests+=1;dd=canonical(S.Matrix([[r*r,r*s,s*s,r,s,1]for r,s in six]).det(method='domain-ge'))
                assert dd!=0,(label,omit,'generic bad conic')
                add_event(dd)
        tested=0;high=0;validfields=0
        for f in list(events.values()):
            mod=[base.from_sympy(c)for c in f.all_coeffs()];cache={}
            def at(z):
                if z not in cache:
                    n,d=nd(z)
                    n=n.rem(f);d=d.rem(f)
                    nn=ANP([base.from_sympy(c)for c in n.all_coeffs()],mod,base)
                    dd=ANP([base.from_sympy(c)for c in d.all_coeffs()],mod,base)
                    if not dd:raise ZeroDivisionError
                    cache[z]=nn/dd
                return cache[z]
            try:AA=list(map(at,A));CC=list(map(at,C))
            except ZeroDivisionError:continue
            if len(set(AA))!=5 or len(set(CC))!=4:continue
            validfields+=1;actual=set()
            # Rebuild maps directly from every pair of specialized points.
            for aa,bb in combinations(range(5),2):
                for cc,dd in permutations(range(4),2):
                    r=(CC[dd]-CC[cc])/(AA[bb]-AA[aa]);s=CC[cc]-r*AA[aa]
                    ims=[r*a+s for a in AA]
                    if sum(x in CC for x in ims)>=3:actual.add((r,s))
            bs=set();ex=defaultdict(set)
            for r,s in actual:
                off=[r*a+s for a in AA if r*a+s not in CC]
                if len(off)==1:bs.add((r,s))
                else:
                    assert len(off)==2
                    for b in off:ex[b].add((r,s))
            assert len(bs)<=4
            for b,mm in ex.items():
                P=bs|mm
                if len(P)<6:continue
                high+=1;bad,nt=conic_bad(P);tested+=nt
                assert not bad,(label,omit,str(f),'algebraic bad conic')
        row={'card':omit,'pair_determined_maps':len(maps),'event_factors':len(events),'valid_fields':validfields,'high_cases':high,'generic_tests':generic_tests,'algebraic_tests':tested,'bad_cases':0,'elapsed':time.time()-started}
        out.append(row);print(json.dumps(row),flush=True)
    result={'label':label,'field':str(base),'cards':out,'seconds':time.time()-started}
    Path('GM_round2/early_gm6_exclusions_fresh/pair_anchor_'+label+'.json').write_text(json.dumps(result,indent=2));return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--family',choices=['golden','positive_14','single_pal_11','third'],required=True);a=p.parse_args()
    if a.family=='golden':
        h=S.sqrt(5)-2;run('golden',[-1,-h,h,1,t],S.QQ.algebraic_field(S.sqrt(5)),(0,S.oo),True)
    elif a.family=='third':run('third',[-1,-S.Rational(1,3),S.Rational(1,3),1,t],S.QQ,(0,S.oo))
    else:
        path='GM_round2/gale_star/rich_conic_'+('parametric_' if a.family=='positive_14' else '')+a.family+'.json'
        d=json.loads(Path(path).read_text())
        if 'points' in d:pts=[S.sympify(x,locals={'t':t})for x in d['points']]
        else:
            pts=[S.Integer(0)]
            for g in d['gaps']:pts.append(pts[-1]+S.sympify(g,locals={'t':t}))
        run(a.family,pts,S.QQ,tuple(S.sympify(x)for x in d['parameter_domain']))
