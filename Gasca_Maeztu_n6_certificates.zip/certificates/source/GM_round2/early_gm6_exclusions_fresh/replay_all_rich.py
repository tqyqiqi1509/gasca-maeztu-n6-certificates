"""Fresh complete replay using the independently written pair-anchor verifier.
No stored maps, event polynomials, or conic verdicts are read.
Only the 34 symbolic source-family descriptions are taken from the original
manifest; their geometric coverage was separately reconstructed by hand.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import contextlib, json, sys, time
sys.path.insert(0, str(Path(__file__).parent))

def job(spec):
    import pair_anchor_replay as a
    import sympy as S
    label, path = spec
    t=a.t
    if label == 'golden':
        h=S.sqrt(5)-2
        A=[-1,-h,h,1,t]; base=S.QQ.algebraic_field(S.sqrt(5)); dom=(0,S.oo); allroots=True
    elif label == 'third':
        A=[-1,-S.Rational(1,3),S.Rational(1,3),1,t];base=S.QQ;dom=(0,S.oo);allroots=False
    else:
        d=json.loads(Path(path).read_text())
        if 'points' in d:
            A=[S.sympify(x,locals={'t':t}) for x in d['points']]
        else:
            A=[S.Integer(0)]
            for g in d['gaps']:A.append(A[-1]+S.sympify(g,locals={'t':t}))
        base=S.QQ;dom=tuple(S.sympify(x) for x in d['parameter_domain']);allroots=False
    with open(Path(__file__).parent/(label+'.log'),'w') as fh, contextlib.redirect_stdout(fh):
        out=a.run(label,A,base,dom,allroots)
    return {'label':label,'cards':len(out['cards']),'fields':sum(x['valid_fields'] for x in out['cards']),
            'tests':sum(x['algebraic_tests'] for x in out['cards']), 'seconds':out['seconds'],'status':'PASS'}

if __name__=='__main__':
    src=Path('GM_round2/gale_star')
    main=['positive_15','positive_14','negative_13','negative_14','symmetric','two_pal_13','two_pal_14','two_pal_15']
    jobs=[(x,str(src/('rich_conic_parametric_'+x+'.json'))) for x in main]
    jobs += [('single_pal_%02d'%i,str(src/('rich_conic_single_pal_%02d.json'%i))) for i in range(24)]
    jobs += [('third',None),('golden',None)]
    started=time.time(); results=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(job,j):j[0] for j in jobs}
        for f in as_completed(futures):
            try:r=f.result()
            except Exception as e:r={'label':futures[f],'status':'FAIL','error':repr(e)}
            results.append(r); print(json.dumps(r),flush=True)
            Path('GM_round2/early_gm6_exclusions_fresh/rich_replay_progress.json').write_text(json.dumps(results,indent=2))
    summary={'families':len(results),'all_pass':all(x['status']=='PASS' for x in results),'seconds':time.time()-started,'results':results}
    Path('GM_round2/early_gm6_exclusions_fresh/rich_replay_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k!='results'}))
