"""Fresh reconstruction of the single-palindrome source reduction.

Run from the proof package root. Reads only the proposed source expressions,
and regenerates them from pair matches on {-1,-t,t,1} before comparing.
"""
from pathlib import Path
import itertools
import json
import sympy as s

t = s.symbols('t')
core = [-s.Integer(1), -t, t, s.Integer(1)]
canon = s.cancel
exceptions, identities, candidates = set(), set(), set()
for source in itertools.combinations(core, 3):
    for target in itertools.permutations(core, 3):
        slope = canon((target[1]-target[0])/(source[1]-source[0]))
        shift = canon(target[0]-slope*source[0])
        equation = canon(slope*source[2]+shift-target[2])
        if equation == 0:
            identities.add((str(slope), str(shift)))
            continue
        for factor, _ in s.factor_list(s.fraction(equation)[0], t)[1]:
            polynomial = s.Poly(factor, t).monic()
            if polynomial.count_roots(0, 1) > 0 and polynomial.as_expr() not in (t, t-1):
                exceptions.add(str(polynomial.as_expr()))
for a, b in itertools.combinations(core, 2):
    for c, d in itertools.permutations(core, 2):
        slope = canon((d-c)/(b-a))
        shift = canon(c-slope*a)
        for w in core:
            if w in (c, d):
                continue
            extra = canon((w-shift)/slope)
            if extra in core:
                continue
            candidates.add(min(str(extra), str(canon(-extra))))
proposed = json.loads(Path('GM_round2/gale_star/single_pal_candidate_A.json').read_text())
proposed_set = {min(str(canon(s.sympify(z))), str(canon(-s.sympify(z))))
                for z in proposed['extra_A_functions']}
assert candidates == proposed_set
assert identities == {('1', '0'), ('-1', '0')}
assert exceptions == {'t - 1/3', 't**2 + 4*t - 1'}
print(json.dumps({'generic_triple_self_maps': sorted(identities),
                  'exception_polynomials': sorted(exceptions),
                  'rational_source_candidates': len(candidates),
                  'candidate_agreement': True, 'status': 'PASS'}))
