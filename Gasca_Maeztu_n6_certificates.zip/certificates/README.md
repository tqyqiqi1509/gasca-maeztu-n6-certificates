# Exact certificates for the Gasca–Maeztu conjecture in degree six

**Qiyue Tang**  
Zhili College, Tsinghua University, Beijing 100084, China  
tangqy24@mails.tsinghua.edu.cn  
November 12, 2026

This package accompanies *The Gasca–Maeztu conjecture in degree six*. It contains the finite incidence certificates and exact algebraic checks used in the proof for **real GC6 sets**.

The programs verify specific auxiliary statements. The article supplies the reductions from arbitrary real configurations to those finite statements, the nonsplit cubic argument, the geometric interfaces, and the final incidence count.

## Run the complete verification

Use Python 3.12 or later, with SymPy 1.14.0. The included complete run used Python 3.12.14 and SymPy 1.14.0.

From this directory:

~~~bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run_all.py --output my_verification
~~~

On Windows, use .venv\Scripts\python.exe in place of .venv/bin/python.

If SymPy 1.14.0 is already installed:

~~~bash
python run_all.py --output my_verification
~~~

The output directory must be new; previous evidence is not overwritten. A complete successful run ends with "all_pass": true and "stages": 9, and returns process exit code zero. The Q1-Q2 stage verifies both shared-factor cases. There is no reduced or quick mode: the command runs all 34 rich-map source families, including the golden field, on all five target cards.

Run ordinary Python. The wrapper rejects python -O and other optimized execution because the preserved verifiers use mathematical assertions. It removes PYTHONOPTIMIZE from child environments.

After dependency installation, verification needs no network connection, commercial solver, external computer algebra system, or service. Four local worker processes run the 34 rich-map families. The package uses exact integers, rational functions, Gröbner bases over the rationals, and algebraic number fields; elapsed-time measurements are the only floating-point quantities used by the driver.

## Certificate map

All paths in this table are relative to **source/GM_round2/**.

| ID | Program | Statement and expected result |
|---|---|---|
| C0 | whole_gm6_dependency_fresh/check_six_coloring.py | Regenerate all 1,899 product-order antichain matchings and 2,991 compatibility edges; check the supplied six-color assignment on every edge. |
| Q0, first generator | support4_fresh/partial_net_latin.py | Generate 1,344 first-row-fixed Latin squares of order five and 56 reduced squares; check all 301,056 square-pair/missing-row choices. The 72 survivors all have cyclic-affine witnesses and complete orthogonally. |
| Q0, independent replay | early_gm6_exclusions_fresh/zero_shared_replay.py | Independently generate simultaneous four-row arrays: 432 raw cases, 72 normalized cases, exactly the same witness set. |
| Q1 and Q2 | support4_fresh/shared_four_carrier_certificate.py | Generate 40 one-sharing and 8 two-sharing cases, with orbit sizes 32+8 and 2+6; verify row transitivity, parametrization necessities, determinant identities, and collinear-center exclusions. |
| A0 | early_gm6_exclusions_fresh/abstract_matching_recheck.py | Generate the 46 candidate perfect matchings directly from linearity; their graph has 58 edges and no triangle. |
| S0 | root/independent_four_lambda_audit.py | Regenerate the 11 two-edge injections, all 121 pairs of equations, and all 32 remaining two-line completions in the eight cubic fields. The counts are 102 forbidden, 11 nonreal/forbidden, and 8 cubic-field systems; every completion fails. |
| S1 | maximal_quartic_fresh/double_lambda_golden_transversals.py | In the exact field defined by z**2-3*z+1, enumerate 12 directed joins; precisely 4 are eligible and precisely one special quartic remains. Check all 12 restriction identities for the three sextics and the nonzero independence minor 4*z-6. |
| R1 | early_gm6_exclusions_fresh/source_family_rebuild.py | Rebuild the 24 rational single-palindrome source functions from pair matches and verify that the only exceptional three-point self-map polynomials are t-1/3 and t**2+4*t-1. |
| R0 | early_gm6_exclusions_fresh/replay_all_rich.py and pair_anchor_replay.py | Verify all 34 source families and all 170 target cards. There are 1,801 valid exceptional fields and 165 noncollinear six-tuple determinant tests; none gives an irreducible-conic obstruction. The golden family contributes 229 fields and 44 tests. |

The 33 rational families contribute 1,572 exceptional fields and 121 determinant tests. These field counts belong to the included pair-anchor algorithm. They need not equal a count from a different activation-event algorithm: extra event factors can lead to additional harmless fields. The mathematical conclusions and the fully specified algorithm are the certificate.

## What is supplied, and what is recomputed

The input JSON files contain:

- The proposed six-color assignment for C0, including the matching labels.
- The proposed Q0 cyclic-affine witnesses. The first Q0 generator overwrites its temporary copy with newly generated witnesses before the independent replay compares them.
- The 11 injection pairs for comparison in S0. The verifier generates these pairs independently and recomputes all equations, elimination results, fields, and completions.
- The eight gap families and 24 single-palindrome source families for R0. Only their symbolic coordinates and domains are retained; historical determinant results and verdicts have been removed.
- The proposed list of 24 source functions for R1, independently rebuilt from affine pair matches.

The runner additionally checks that the 32 rational family JSON files are exactly the families specified in the article, including domains and the 24 functions up to sign. The two special families are constructed explicitly by the R0 driver.

The supplied colors and symbolic family descriptions are not accepted as previously verified truth. All vertices and edges are rebuilt before checking the colors. The source-family coverage proof appears in the article, R1 regenerates its exceptional formula catalogue, and R0 regenerates every map and exceptional field from those formulas.

For R0, every four-rich affine map sends at least three source points into a fixed target card of size four. It is therefore determined by one of the enumerated two-point assignments. The code collects all exceptional activation, target-merger and conic-determinant factors; at every valid factor it rebuilds the affine maps from specialized point pairs. It does not specialize a cached generic map list. The golden source family is checked over QQ(sqrt(5)), including all factors, so no numerical choice of an algebraic conjugate is used.

These computations concern finite **incidence types with unrestricted real parameters**. No bounded coordinate universe, random test, numerical tolerance, or sampling grid is used to decide a proof assertion.

## Results and integrity

The directory **verification_results/** contains the complete run delivered with this package. All nine stages passed in 211.77 seconds in the recorded environment; the complete R0 stage took 199.81 seconds. These are observed runtimes, not hardware-independent bounds. Your new run writes:

- **summary.json**: environment, hash checks, stage status, validated counts and total runtime.
- One console log per stage.
- **generated/GM_round2/**: all newly generated or changed JSON records and rich-family progress logs.

The runner works in a temporary copy of the source tree, copies its generated evidence to the chosen output directory, and then removes the temporary tree. The original certificate inputs remain unchanged.

**SHA256SUMS.json** covers every executable, exact input, dependency pin and provenance file. The wrapper checks it before running. **PROVENANCE.json** records which audited files were preserved byte for byte and which JSON inputs were reduced to their actually used symbolic fields.

The nine-stage wrapper independently validates the result files. In particular, the rich-family driver records worker failures rather than raising them itself; the wrapper checks all_pass, the full set of 34 distinct family labels, all 170 card records, and every bad_cases value, and returns a failure if any required result is absent or invalid.

The Python and SymPy implementations remain part of the computational basis. The package is an executable exact certificate check, not a proof-assistant formalization.
