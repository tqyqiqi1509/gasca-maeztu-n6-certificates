#!/usr/bin/env python3
"""Regenerate and verify every retained certificate for the real GC6 proof.

This runner uses an isolated temporary copy, keeps assertions enabled, and
checks the generated outputs independently of each script's process status.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time

BASE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def source_manifest():
    manifest = BASE / "SHA256SUMS.json"
    if not manifest.exists():
        return {"checked": False, "reason": "manifest not installed"}
    entries = read_json(manifest)["files"]
    for name, expected in entries.items():
        path = BASE / name
        require(path.is_file(), f"Missing package file: {name}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        require(actual == expected, f"SHA-256 mismatch: {name}")
    return {"checked": True, "files": len(entries)}


def source_catalogue(root):
    """Check that the 32 JSON sources equal the families stated in the text."""
    import sympy as s
    t = s.symbols("t")
    expected = {
        "positive_15": (["1", "t", "t**2", "t**3"], ["0", "oo"]),
        "positive_14": (["1", "t", "t**2", "t**3/(1-t)"], ["0", "1"]),
        "negative_13": (["t**2", "1", "1/(t-1)", "t"], ["1", "oo"]),
        "negative_14": (["1/t**2-1", "1", "t", "1/t-t"], ["0", "1"]),
        "symmetric": (["1", "t", "t", "1"], ["0", "oo"]),
        "two_pal_13": (["1", "1", "t", "1"], ["0", "oo"]),
        "two_pal_14": (["1+t", "1", "t", "1"], ["0", "oo"]),
        "two_pal_15": (["1", "t", "1", "t"], ["0", "oo"]),
    }
    path = root / "GM_round2/gale_star"
    for name, (gaps, domain) in expected.items():
        d = read_json(path / f"rich_conic_parametric_{name}.json")
        require(d["parameter_domain"] == domain, f"Wrong domain for {name}")
        require(len(d["gaps"]) == 4, f"Wrong gap count for {name}")
        require(all(s.cancel(s.sympify(a) - s.sympify(b)) == 0
                    for a, b in zip(d["gaps"], gaps)), f"Wrong gaps for {name}")
    def canonical_up_to_sign(z):
        z = s.cancel(s.sympify(z))
        return min(str(z), str(s.cancel(-z)))
    proposed = read_json(path / "single_pal_candidate_A.json")
    target = {canonical_up_to_sign(z) for z in proposed["extra_A_functions"]}
    actual = set()
    core = [-s.Integer(1), -t, t, s.Integer(1)]
    for i in range(24):
        d = read_json(path / f"rich_conic_single_pal_{i:02d}.json")
        points = [s.sympify(z) for z in d["points"]]
        require(d["parameter_domain"] == ["0", "1"], "Wrong palindrome domain")
        require(len(points) == 5 and points[:4] == core, "Wrong palindrome card")
        actual.add(canonical_up_to_sign(points[4]))
    require(len(actual) == len(target) == 24 and actual == target,
            "The 24 source files do not equal the regenerated candidate list")
    return {"gap_families": 8, "single_palindrome_families": 24,
            "special_families_in_verifier": 2, "status": "PASS"}


def validate(code, root, log):
    p = root / "GM_round2"
    if code == "C0":
        d = read_json(p / "whole_gm6_dependency_fresh/six_coloring_audit.json")
        require(d["status"] == "PASS" and
                (d["regenerated_vertices"], d["regenerated_edges"],
                 d["certificate_colors"]) == (1899, 2991, 6), "C0 output mismatch")
        return d
    if code == "Q0-generator":
        d = read_json(p / "support4_fresh/partial_net_latin.json")
        require((d["first_row_normalized_squares"], d["reduced_squares"],
                 d["pairs_and_missing_rows_checked"], d["affine_certificate_count"])
                == (1344, 56, 301056, 72), "Q0 Latin count mismatch")
        require(d["nonaffine_survivors"] == [] and
                d["completion_new_triples_histogram"] == {"5": 72},
                "Q0 has a nonaffine or incomplete survivor")
        return {k: d[k] for k in (
            "first_row_normalized_squares", "reduced_squares",
            "pairs_and_missing_rows_checked", "affine_certificate_count",
            "completion_new_triples_histogram", "nonaffine_survivors")}
    if code == "Q0-replay":
        d = read_json(p / "early_gm6_exclusions_fresh/zero_shared_replay.json")
        require((d["firstrow_fixed_fourrow_patterns"],
                 d["normalized_with_distinguished_missing_row"]) == (432, 72),
                "Q0 replay count mismatch")
        for key in ("exactly_equal_supplied_certificate",
                    "all_completions_orthogonal", "all_have_cyclic_affine_witness",
                    "every_three_carrier_labels_arithmetic_progression"):
            require(d[key] is True, f"Q0 replay failed: {key}")
        return d
    if code == "Q1-Q2":
        d = read_json(p / "support4_fresh/shared_four_carrier_certificate.json")
        require(d["status"] == "all assertions passed", "Q1/Q2 assertions failed")
        require(d["enumeration_counts"] == {
            "latin4_firstrow_identity": 24, "latin4_reduced": 4,
            "latin5_firstrow_identity": 1344, "one_shared": 40, "two_shared": 8},
            "Q1/Q2 enumeration count mismatch")
        one = sorted(x["count"] for x in d["one_shared_orbits"])
        two = sorted(x["count"] for x in d["two_shared_orbits"])
        require(one == [8, 32] and two == [2, 6], "Q1/Q2 orbit count mismatch")
        require(len(d["records"]) == 3, "Q1/Q2 coordinate record missing")
        return {"enumeration_counts": d["enumeration_counts"],
                "one_shared_orbits": one, "two_shared_orbits": two,
                "parametrization_records": len(d["records"]), "status": "PASS"}
    if code == "A0":
        d = read_json(p / "early_gm6_exclusions_fresh/abstract_matching_recheck.json")
        require(d["status"] == "PASS" and
                (d["candidates"], d["edges"], d["triangles"]) == (46, 58, 0),
                "A0 output mismatch")
        return d
    if code == "S0":
        d = read_json(p / "root/independent_four_lambda_audit.json")
        require(d["status"] == "PASS" and d["injection_count"] == 11,
                "S0 failed")
        require(d["counts"] == {"forbidden": 102, "nonreal_or_forbidden": 11,
                                "cubic": 8}, "S0 system counts changed")
        require(len(d["cases"]) == 121 and len(d["completion"]) == 8,
                "S0 coverage count mismatch")
        checks = [c for row in d["completion"] for c in row["checks"]]
        require(len(checks) == 32 and
                all(c["matches_all_four"] is False for c in checks),
                "S0 surviving real completion")
        return {"counts": d["counts"], "injections": 11, "systems": 121,
                "completion_checks": 32, "status": "PASS"}
    if code == "S1":
        d = read_json(p / "maximal_quartic_fresh/double_lambda_golden_transversals.json")
        eligible = sorted(tuple(e["pair"]) for e in d["edges"] if e["eligible"])
        require(len(d["edges"]) == 12 and
                eligible == [(0, 1), (1, 0), (2, 3), (3, 2)],
                "S1 candidate edge mismatch")
        require(d["quartic_permutations"] == [[1, 0, 3, 2]],
                "S1 special quartic is not unique")
        require(len(d["sextics"]) == len(d["restriction_checks"]) == 3,
                "S1 missing positive control")
        require(all(c["restriction_remainders"] == ["0"] * 4
                    for c in d["restriction_checks"]), "S1 restriction failure")
        require(d["independence_minor"]["determinant"] == "4*z - 6",
                "S1 independence minor mismatch")
        return {"directed_candidates": 12, "eligible_edges": eligible,
                "special_quartics": 1, "restriction_identities": 12,
                "independence_minor": d["independence_minor"], "status": "PASS"}
    if code == "R1":
        rows = [json.loads(line) for line in log.read_text().splitlines()
                if line.lstrip().startswith("{")]
        require(len(rows) == 1, "R1 expected one JSON result")
        d = rows[0]
        require(d["status"] == "PASS" and d["candidate_agreement"] is True and
                d["rational_source_candidates"] == 24, "R1 source classification failed")
        require(d["exception_polynomials"] == ["t - 1/3", "t**2 + 4*t - 1"],
                "R1 exception classification changed")
        return d
    if code == "R0":
        d = read_json(p / "early_gm6_exclusions_fresh/rich_replay_summary.json")
        require(d["all_pass"] is True and d["families"] == 34 and
                len(d["results"]) == 34, "R0 incomplete or failed family run")
        expected = {"positive_15", "positive_14", "negative_13", "negative_14",
                    "symmetric", "two_pal_13", "two_pal_14", "two_pal_15",
                    "third", "golden"} | {f"single_pal_{i:02d}" for i in range(24)}
        require({r["label"] for r in d["results"]} == expected,
                "R0 family coverage mismatch")
        require(all(r["status"] == "PASS" and r["cards"] == 5 for r in d["results"]),
                "R0 incomplete target-card run")
        fields = sum(r["fields"] for r in d["results"])
        checks = sum(r["tests"] for r in d["results"])
        require((fields, checks) == (1801, 165), "R0 field/determinant totals changed")
        golden = next(r for r in d["results"] if r["label"] == "golden")
        require((golden["fields"], golden["tests"]) == (229, 44),
                "R0 golden field coverage mismatch")
        for label in expected:
            detail = read_json(p / f"early_gm6_exclusions_fresh/pair_anchor_{label}.json")
            require(len(detail["cards"]) == 5 and
                    {c["card"] for c in detail["cards"]} == set(range(5)) and
                    all(c["bad_cases"] == 0 for c in detail["cards"]),
                    f"R0 bad or missing card in {label}")
        return {"families": 34, "target_cards": 170, "valid_fields": fields,
                "noncollinear_six_tuple_tests": checks,
                "golden_valid_fields": 229, "golden_tests": 44, "status": "PASS"}
    raise RuntimeError(f"Unknown certificate: {code}")


STAGES = [
    ("C0", "whole_gm6_dependency_fresh/check_six_coloring.py"),
    ("Q0-generator", "support4_fresh/partial_net_latin.py"),
    ("Q0-replay", "early_gm6_exclusions_fresh/zero_shared_replay.py"),
    ("Q1-Q2", "support4_fresh/shared_four_carrier_certificate.py"),
    ("A0", "early_gm6_exclusions_fresh/abstract_matching_recheck.py"),
    ("S0", "root/independent_four_lambda_audit.py"),
    ("S1", "maximal_quartic_fresh/double_lambda_golden_transversals.py"),
    ("R1", "early_gm6_exclusions_fresh/source_family_rebuild.py"),
    ("R0", "early_gm6_exclusions_fresh/replay_all_rich.py"),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=BASE / "verification_results",
                        help="new result directory (must not already exist)")
    args = parser.parse_args()
    require(__debug__ and not sys.flags.optimize,
            "Run ordinary Python, without -O or PYTHONOPTIMIZE.")
    require(sys.version_info >= (3, 12), "Python 3.12 or later is required.")
    import sympy
    require(sympy.__version__ == "1.14.0", "Install the pinned SymPy 1.14.0.")
    output = args.output.resolve()
    require(not output.exists(), f"Output already exists: {output}; choose --output NEW_DIR")
    output.mkdir(parents=True)
    manifest = source_manifest()
    started = time.monotonic()
    result = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(), "sympy": sympy.__version__,
        "platform": platform.platform(), "manifest": manifest,
        "all_pass": False, "stages": [],
    }
    env = os.environ.copy()
    env.pop("PYTHONOPTIMIZE", None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    work = Path(tempfile.mkdtemp(prefix="gm6_certificates_"))
    try:
        shutil.copytree(BASE / "source/GM_round2", work / "GM_round2")
        result["source_catalogue"] = source_catalogue(work)
        for code, relative in STAGES:
            stamp = time.monotonic()
            log = output / (code + ".log")
            print(f"[{code}] running", flush=True)
            with log.open("w", encoding="utf-8") as handle:
                completed = subprocess.run(
                    [sys.executable, "-B", str(work / "GM_round2" / relative)],
                    cwd=work, env=env, stdout=handle, stderr=subprocess.STDOUT,
                    check=False)
            require(completed.returncode == 0,
                    f"{code} exited with code {completed.returncode}; see {log}")
            details = validate(code, work, log)
            row = {"id": code, "status": "PASS",
                   "seconds": round(time.monotonic() - stamp, 6), "result": details}
            result["stages"].append(row)
            (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
            print(f"[{code}] PASS ({row['seconds']:.3f} s)", flush=True)
        result["all_pass"] = True
    except Exception as exc:
        result["error"] = str(exc)
        print(f"FAIL: {exc}", file=sys.stderr, flush=True)
    finally:
        result["seconds"] = round(time.monotonic() - started, 6)
        result["completed_utc"] = datetime.now(timezone.utc).isoformat()
        generated = output / "generated/GM_round2"
        for source in sorted((work / "GM_round2").rglob("*")):
            if source.is_file() and source.suffix in {".json", ".log"}:
                original = BASE / "source" / source.relative_to(work)
                if original.exists() and original.read_bytes() == source.read_bytes():
                    continue
                destination = generated / source.relative_to(work / "GM_round2")
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
        (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
        shutil.rmtree(work)
    print(json.dumps({"all_pass": result["all_pass"],
                      "stages": len(result["stages"]),
                      "seconds": result["seconds"], "output": str(output)}), flush=True)
    return 0 if result["all_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
